%path('../../musc_skel/arm', path);
%path('../../learning/backprop', path);
%path('../../learning/pca', path);
%path('post', path);
%path('../gdata_2005_07',path);
