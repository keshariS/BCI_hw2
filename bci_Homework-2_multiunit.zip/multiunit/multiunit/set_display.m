function set_display(newval)


global parms;

parms.fig.showelems = newval;


